class Component < ApplicationRecord
end
