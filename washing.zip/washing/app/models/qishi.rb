class Qishi < ApplicationRecord
end
