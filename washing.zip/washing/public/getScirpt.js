function fn(){
	$("#message").show(3000);
}
fn();