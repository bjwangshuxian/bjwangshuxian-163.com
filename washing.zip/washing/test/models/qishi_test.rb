require 'test_helper'

class QishiTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
